import { sql } from 'drizzle-orm';
import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (IMPORTANT: mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (IMPORTANT: mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Bible verses table
export const verses = pgTable("verses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reference: text("reference").notNull(), // e.g., "John 3:16"
  text: text("text").notNull(),
  category: text("category"), // e.g., "Hope", "Faith", "Love"
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVerseSchema = createInsertSchema(verses).omit({
  id: true,
  createdAt: true,
});

export type InsertVerse = z.infer<typeof insertVerseSchema>;
export type Verse = typeof verses.$inferSelect;

// Daily devotions table
export const devotions = pgTable("devotions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: timestamp("date").notNull(),
  title: text("title").notNull(),
  scriptureReference: text("scripture_reference").notNull(),
  reflectionText: text("reflection_text").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDevotionSchema = createInsertSchema(devotions).omit({
  id: true,
  createdAt: true,
});

export type InsertDevotion = z.infer<typeof insertDevotionSchema>;
export type Devotion = typeof devotions.$inferSelect;

// Practice sessions tracking
export const practiceSessions = pgTable("practice_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  verseId: varchar("verse_id").notNull().references(() => verses.id),
  accuracy: real("accuracy").notNull(), // 0-100
  practiceType: text("practice_type").notNull(), // "typing" | "speech"
  completedAt: timestamp("completed_at").defaultNow(),
});

export const insertPracticeSessionSchema = createInsertSchema(practiceSessions).omit({
  id: true,
  completedAt: true,
});

export type InsertPracticeSession = z.infer<typeof insertPracticeSessionSchema>;
export type PracticeSession = typeof practiceSessions.$inferSelect;

// User progress summary
export const userProgress = pgTable("user_progress", {
  userId: varchar("user_id").primaryKey().references(() => users.id),
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  totalVersesPracticed: integer("total_verses_practiced").notNull().default(0),
  totalPoints: integer("total_points").notNull().default(0),
  lastPracticeDate: timestamp("last_practice_date"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserProgressSchema = createInsertSchema(userProgress).omit({
  updatedAt: true,
});

export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type UserProgress = typeof userProgress.$inferSelect;

// Achievements definitions
export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  iconType: text("icon_type").notNull(), // "scroll", "flame", "trophy", "star"
  requirement: integer("requirement").notNull(), // threshold to unlock
  category: text("category").notNull(), // "verses", "streak", "accuracy"
});

export const insertAchievementSchema = createInsertSchema(achievements);

export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

// User achievements (unlocked)
export const userAchievements = pgTable("user_achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  achievementId: varchar("achievement_id").notNull().references(() => achievements.id),
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({
  id: true,
  unlockedAt: true,
});

export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type UserAchievement = typeof userAchievements.$inferSelect;

// Favorite devotions
export const favoriteDevotions = pgTable("favorite_devotions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  devotionId: varchar("devotion_id").notNull().references(() => devotions.id),
  favoritedAt: timestamp("favorited_at").defaultNow(),
});

export const insertFavoriteDevotionSchema = createInsertSchema(favoriteDevotions).omit({
  id: true,
  favoritedAt: true,
});

export type InsertFavoriteDevotion = z.infer<typeof insertFavoriteDevotionSchema>;
export type FavoriteDevotion = typeof favoriteDevotions.$inferSelect;

// Read devotions
export const readDevotions = pgTable("read_devotions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  devotionId: varchar("devotion_id").notNull().references(() => devotions.id),
  readAt: timestamp("read_at").defaultNow(),
});

export const insertReadDevotionSchema = createInsertSchema(readDevotions).omit({
  id: true,
  readAt: true,
});

export type InsertReadDevotion = z.infer<typeof insertReadDevotionSchema>;
export type ReadDevotion = typeof readDevotions.$inferSelect;

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  progress: one(userProgress),
  practiceSessions: many(practiceSessions),
  userAchievements: many(userAchievements),
  favoriteDevotions: many(favoriteDevotions),
  readDevotions: many(readDevotions),
}));

export const versesRelations = relations(verses, ({ many }) => ({
  practiceSessions: many(practiceSessions),
}));

export const devotionsRelations = relations(devotions, ({ many }) => ({
  favoriteDevotions: many(favoriteDevotions),
  readDevotions: many(readDevotions),
}));
