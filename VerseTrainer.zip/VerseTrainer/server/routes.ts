import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertVerseSchema,
  insertDevotionSchema,
  insertPracticeSessionSchema,
  insertFavoriteDevotionSchema,
  insertReadDevotionSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Verse routes
  app.get('/api/verses', isAuthenticated, async (req, res) => {
    try {
      const verses = await storage.getAllVerses();
      res.json(verses);
    } catch (error) {
      console.error("Error fetching verses:", error);
      res.status(500).json({ message: "Failed to fetch verses" });
    }
  });

  app.get('/api/verses/:id', isAuthenticated, async (req, res) => {
    try {
      const verse = await storage.getVerse(req.params.id);
      if (!verse) {
        return res.status(404).json({ message: "Verse not found" });
      }
      res.json(verse);
    } catch (error) {
      console.error("Error fetching verse:", error);
      res.status(500).json({ message: "Failed to fetch verse" });
    }
  });

  app.post('/api/verses', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertVerseSchema.parse(req.body);
      const verse = await storage.createVerse(validatedData);
      res.status(201).json(verse);
    } catch (error) {
      console.error("Error creating verse:", error);
      res.status(400).json({ message: "Invalid verse data" });
    }
  });

  // Devotion routes
  app.get('/api/devotions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const devotions = await storage.getAllDevotions(userId);
      res.json(devotions);
    } catch (error) {
      console.error("Error fetching devotions:", error);
      res.status(500).json({ message: "Failed to fetch devotions" });
    }
  });

  app.post('/api/devotions', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertDevotionSchema.parse(req.body);
      const devotion = await storage.createDevotion(validatedData);
      res.status(201).json(devotion);
    } catch (error) {
      console.error("Error creating devotion:", error);
      res.status(400).json({ message: "Invalid devotion data" });
    }
  });

  // Favorite devotion routes
  app.post('/api/devotions/favorite', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertFavoriteDevotionSchema.parse({
        ...req.body,
        userId,
      });
      const favorite = await storage.addFavoriteDevotion(validatedData);
      res.status(201).json(favorite);
    } catch (error) {
      console.error("Error adding favorite:", error);
      res.status(400).json({ message: "Failed to add favorite" });
    }
  });

  app.delete('/api/devotions/:devotionId/favorite', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.removeFavoriteDevotion(userId, req.params.devotionId);
      res.status(204).send();
    } catch (error) {
      console.error("Error removing favorite:", error);
      res.status(500).json({ message: "Failed to remove favorite" });
    }
  });

  // Read devotion routes
  app.post('/api/devotions/read', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertReadDevotionSchema.parse({
        ...req.body,
        userId,
      });
      const read = await storage.markDevotionAsRead(validatedData);
      res.status(201).json(read);
    } catch (error) {
      console.error("Error marking as read:", error);
      res.status(400).json({ message: "Failed to mark as read" });
    }
  });

  // Practice session routes
  app.post('/api/practice', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertPracticeSessionSchema.parse({
        ...req.body,
        userId,
      });
      
      // Create practice session
      const session = await storage.createPracticeSession(validatedData);
      
      // Update user progress
      const currentProgress = await storage.getUserProgress(userId);
      const newTotal = (currentProgress?.totalVersesPracticed || 0) + 1;
      
      // Calculate points (10 base points + accuracy bonus)
      const points = Math.round(10 + (validatedData.accuracy / 10));
      const newPoints = (currentProgress?.totalPoints || 0) + points;
      
      // Update streak
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const lastPractice = currentProgress?.lastPracticeDate;
      let newStreak = currentProgress?.currentStreak || 0;
      let longestStreak = currentProgress?.longestStreak || 0;
      
      if (lastPractice) {
        const lastDate = new Date(lastPractice);
        lastDate.setHours(0, 0, 0, 0);
        const daysDiff = Math.floor((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (daysDiff === 0) {
          // Same day, keep streak
        } else if (daysDiff === 1) {
          // Next day, increment streak
          newStreak += 1;
          longestStreak = Math.max(longestStreak, newStreak);
        } else {
          // Streak broken, reset to 1
          newStreak = 1;
        }
      } else {
        // First practice
        newStreak = 1;
        longestStreak = 1;
      }
      
      await storage.updateUserProgress(userId, {
        userId,
        totalVersesPracticed: newTotal,
        totalPoints: newPoints,
        currentStreak: newStreak,
        longestStreak: longestStreak,
        lastPracticeDate: new Date(),
      });
      
      // Check for achievement unlocks
      const allAchievements = await storage.getAllAchievements();
      const userAchievements = await storage.getUserAchievements(userId);
      const unlockedIds = new Set(userAchievements.map(ua => ua.achievementId));
      
      for (const achievement of allAchievements) {
        if (unlockedIds.has(achievement.id)) continue;
        
        let shouldUnlock = false;
        switch (achievement.category) {
          case "verses":
            shouldUnlock = newTotal >= achievement.requirement;
            break;
          case "streak":
            shouldUnlock = newStreak >= achievement.requirement;
            break;
          case "accuracy":
            shouldUnlock = validatedData.accuracy >= achievement.requirement;
            break;
        }
        
        if (shouldUnlock) {
          await storage.unlockAchievement({
            userId,
            achievementId: achievement.id,
          });
        }
      }
      
      res.status(201).json(session);
    } catch (error) {
      console.error("Error creating practice session:", error);
      res.status(400).json({ message: "Failed to record practice" });
    }
  });

  // Progress routes
  app.get('/api/progress', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const progress = await storage.getUserProgress(userId);
      if (!progress) {
        // Initialize progress if not exists
        const newProgress = await storage.updateUserProgress(userId, {
          userId,
          currentStreak: 0,
          longestStreak: 0,
          totalVersesPracticed: 0,
          totalPoints: 0,
        });
        return res.json(newProgress);
      }
      res.json(progress);
    } catch (error) {
      console.error("Error fetching progress:", error);
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });

  // Achievement routes
  app.get('/api/achievements', isAuthenticated, async (req, res) => {
    try {
      const achievements = await storage.getAllAchievements();
      res.json(achievements);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  app.get('/api/achievements/unlocked', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userAchievements = await storage.getUserAchievements(userId);
      res.json(userAchievements);
    } catch (error) {
      console.error("Error fetching user achievements:", error);
      res.status(500).json({ message: "Failed to fetch user achievements" });
    }
  });

  // Leaderboard route
  app.get('/api/leaderboard', isAuthenticated, async (req, res) => {
    try {
      const leaderboard = await storage.getLeaderboard(100);
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
