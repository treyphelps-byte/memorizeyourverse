import { db } from "./db";
import { verses, devotions, achievements } from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  // Seed verses
  const sampleVerses = [
    {
      reference: "John 3:16",
      text: "For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life.",
      category: "Love",
    },
    {
      reference: "Philippians 4:13",
      text: "I can do all this through him who gives me strength.",
      category: "Strength",
    },
    {
      reference: "Jeremiah 29:11",
      text: "For I know the plans I have for you, declares the Lord, plans to prosper you and not to harm you, plans to give you hope and a future.",
      category: "Hope",
    },
    {
      reference: "Proverbs 3:5-6",
      text: "Trust in the Lord with all your heart and lean not on your own understanding; in all your ways submit to him, and he will make your paths straight.",
      category: "Faith",
    },
    {
      reference: "Romans 8:28",
      text: "And we know that in all things God works for the good of those who love him, who have been called according to his purpose.",
      category: "Faith",
    },
    {
      reference: "Psalm 23:1",
      text: "The Lord is my shepherd, I lack nothing.",
      category: "Peace",
    },
    {
      reference: "Matthew 6:33",
      text: "But seek first his kingdom and his righteousness, and all these things will be given to you as well.",
      category: "Faith",
    },
    {
      reference: "Isaiah 40:31",
      text: "But those who hope in the Lord will renew their strength. They will soar on wings like eagles; they will run and not grow weary, they will walk and not be faint.",
      category: "Strength",
    },
  ];

  try {
    await db.insert(verses).values(sampleVerses).onConflictDoNothing();
    console.log("✓ Verses seeded");
  } catch (error) {
    console.error("Error seeding verses:", error);
  }

  // Seed devotions
  const sampleDevotions = [
    {
      date: new Date("2025-01-20"),
      title: "Walking in Faith",
      scriptureReference: "Hebrews 11:1",
      reflectionText: "Faith is confidence in what we hope for and assurance about what we do not see. Today, reflect on the areas of your life where you need to exercise greater faith. Remember that faith isn't the absence of doubt, but the choice to trust God despite our uncertainties. What step of faith is God calling you to take today?",
    },
    {
      date: new Date("2025-01-21"),
      title: "The Power of Gratitude",
      scriptureReference: "1 Thessalonians 5:16-18",
      reflectionText: "Rejoice always, pray continually, give thanks in all circumstances. Gratitude transforms our perspective and opens our hearts to God's blessings. Take a moment today to list three things you're grateful for. Notice how this simple practice shifts your focus from what you lack to the abundance God has already provided.",
    },
    {
      date: new Date("2025-01-22"),
      title: "Love Your Neighbor",
      scriptureReference: "Mark 12:31",
      reflectionText: "The second greatest commandment is to love your neighbor as yourself. But who is your neighbor? Jesus taught us through the parable of the Good Samaritan that our neighbor is anyone in need we encounter. Today, look for opportunities to show Christ's love to those around you through simple acts of kindness.",
    },
    {
      date: new Date("2025-01-23"),
      title: "Finding Peace in the Storm",
      scriptureReference: "Philippians 4:6-7",
      reflectionText: "Do not be anxious about anything, but in every situation, by prayer and petition, with thanksgiving, present your requests to God. In our fast-paced world, anxiety can easily overwhelm us. But God offers a peace that transcends understanding. What worries are you carrying today? Bring them to God in prayer and experience His perfect peace.",
    },
    {
      date: new Date("2025-01-24"),
      title: "Renewing Your Strength",
      scriptureReference: "Isaiah 40:31",
      reflectionText: "Those who hope in the Lord will renew their strength. When we feel weary and worn, God promises to restore us. Like eagles soaring on thermal currents, we can rise above our circumstances when we trust in Him. Today, take time to rest in God's presence and allow Him to renew your strength for the journey ahead.",
    },
  ];

  try {
    await db.insert(devotions).values(sampleDevotions).onConflictDoNothing();
    console.log("✓ Devotions seeded");
  } catch (error) {
    console.error("Error seeding devotions:", error);
  }

  // Seed achievements
  const sampleAchievements = [
    {
      id: "first-verse",
      name: "First Steps",
      description: "Practice your first verse",
      iconType: "scroll",
      requirement: 1,
      category: "verses",
    },
    {
      id: "ten-verses",
      name: "Getting Started",
      description: "Practice 10 verses",
      iconType: "scroll",
      requirement: 10,
      category: "verses",
    },
    {
      id: "fifty-verses",
      name: "Dedicated Learner",
      description: "Practice 50 verses",
      iconType: "scroll",
      requirement: 50,
      category: "verses",
    },
    {
      id: "hundred-verses",
      name: "Century Club",
      description: "Practice 100 verses",
      iconType: "trophy",
      requirement: 100,
      category: "verses",
    },
    {
      id: "week-streak",
      name: "Week Warrior",
      description: "Maintain a 7-day streak",
      iconType: "flame",
      requirement: 7,
      category: "streak",
    },
    {
      id: "month-streak",
      name: "Consistent Devotion",
      description: "Maintain a 30-day streak",
      iconType: "flame",
      requirement: 30,
      category: "streak",
    },
    {
      id: "perfect-accuracy",
      name: "Word Perfect",
      description: "Achieve 100% accuracy",
      iconType: "star",
      requirement: 100,
      category: "accuracy",
    },
  ];

  try {
    await db.insert(achievements).values(sampleAchievements).onConflictDoNothing();
    console.log("✓ Achievements seeded");
  } catch (error) {
    console.error("Error seeding achievements:", error);
  }

  console.log("Database seeding complete!");
}

seed()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("Seeding failed:", error);
    process.exit(1);
  });
