# VerseTrainer

## Overview

VerseTrainer is a Bible verse memorization application that helps users memorize scripture through interactive practice sessions with speech recognition and typing modes. The platform includes daily devotions, gamification features with achievements and leaderboards, and comprehensive progress tracking. Built as a full-stack application with React frontend and Express backend, it uses Replit's authentication system for user management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript, using Vite as the build tool and development server.

**UI Component System**: The application uses shadcn/ui component library with Radix UI primitives, providing a consistent design system. Components follow the "New York" style variant with Tailwind CSS for styling. The theme system supports light and dark modes through a custom ThemeProvider.

**Routing**: Client-side routing implemented with Wouter, a lightweight alternative to React Router. Main routes include:
- Landing page (public)
- Home dashboard (authenticated)
- Memorize interface (authenticated)
- Devotions (authenticated)
- Leaderboard (authenticated)
- Profile (authenticated)

**State Management**: TanStack Query (React Query) handles server state, data fetching, and caching. The query client is configured with custom error handling and prevents automatic refetching to optimize API calls.

**Design Philosophy**: The application draws inspiration from learning apps like Duolingo and spiritual/wellness applications. Typography uses three font families: Merriweather for headings (timeless wisdom), Inter for body text (readability), and Crimson Text for verse display (elegant scripture presentation).

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript, using ES modules.

**API Design**: RESTful API structure with route handlers organized by resource type:
- `/api/auth/*` - User authentication endpoints
- `/api/verses/*` - Bible verse CRUD operations
- `/api/devotions/*` - Daily devotion management
- `/api/practice/*` - Practice session tracking
- `/api/progress/*` - User progress and statistics
- `/api/achievements/*` - Achievement system
- `/api/leaderboard/*` - Global rankings

**Authentication Strategy**: Replit's OpenID Connect authentication with Passport.js strategy. Session management uses express-session with PostgreSQL storage (connect-pg-simple). Sessions persist for 7 days with secure, httpOnly cookies.

**Data Access Layer**: Storage abstraction pattern with an IStorage interface that defines all data operations. This approach decouples business logic from database implementation, making it easier to swap or mock data sources.

### Database Design

**ORM**: Drizzle ORM with PostgreSQL dialect, using Neon's serverless driver for connection pooling and WebSocket support.

**Schema Structure**:
- **sessions**: Required for Replit Auth, stores session data with expiration
- **users**: User profiles with email, names, and profile images
- **verses**: Bible verses with reference, text, and category
- **devotions**: Daily devotional content with dates and themes
- **practiceSessions**: Individual practice attempts with accuracy and completion metrics
- **userProgress**: Aggregate user statistics (verses memorized, current streak, total points)
- **achievements**: Achievement definitions with unlock criteria
- **userAchievements**: Junction table tracking unlocked achievements per user
- **favoriteDevotions**: User-devotion relationship for favorites
- **readDevotions**: Tracking which devotions users have completed

**Data Validation**: Drizzle-zod generates Zod schemas from database tables for type-safe validation of API inputs.

### Key Features Architecture

**Speech Recognition**: Browser-native Web Speech API for voice-based verse recitation practice. The application compares spoken input against verse text word-by-word to provide real-time accuracy feedback.

**Gamification System**: 
- Point accumulation based on practice accuracy
- Streak tracking for consecutive days of practice
- Achievement unlocking based on milestones
- Global leaderboard ranking users by total points

**Progress Tracking**: Centralized userProgress records maintain:
- Total verses memorized count
- Current and longest streak days
- Total accumulated points
- Last practice timestamp for streak calculation

## External Dependencies

### Authentication Service
**Replit Auth**: OpenID Connect provider handling user authentication. The application must implement mandatory session storage in PostgreSQL and user upsert operations. Environment variables required: `REPL_ID`, `ISSUER_URL`, `SESSION_SECRET`, `REPLIT_DOMAINS`.

### Database
**Neon Postgres**: Serverless PostgreSQL database accessed via `DATABASE_URL` environment variable. Uses WebSocket connections for serverless compatibility with connection pooling.

### UI Libraries
**shadcn/ui**: Component library built on Radix UI primitives, providing accessible, unstyled components that are styled with Tailwind CSS. Configured with path aliases for easy imports.

**Radix UI**: Headless UI primitives for complex components (dialogs, dropdowns, tooltips, etc.) ensuring accessibility and keyboard navigation.

**Tailwind CSS**: Utility-first CSS framework with custom design tokens defined in configuration. Extended with custom colors, border radius values, and CSS variables for theming.

### Fonts
**Google Fonts**: Three font families loaded via CDN:
- Merriweather (serif, headings)
- Inter (sans-serif, body)
- Crimson Text (serif, verses)

### Development Tools
**Replit-specific plugins**: Development environment includes Replit's Vite plugins for runtime error overlay, cartographer (code mapping), and dev banner when running in Replit environment.

### Build Tools
- **Vite**: Frontend build tool and dev server with HMR
- **esbuild**: Backend bundling for production deployment
- **TypeScript**: Type checking across the entire codebase
- **Drizzle Kit**: Database migration tool and schema management