import { useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { BookOpen, Flame, Target, TrendingUp, Award, Calendar } from "lucide-react";
import type { UserProgress, Achievement, UserAchievement } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: progress, isLoading: progressLoading } = useQuery<UserProgress>({
    queryKey: ["/api/progress"],
  });

  const { data: unlockedAchievements, isLoading: achievementsLoading } = useQuery<(UserAchievement & { achievement: Achievement })[]>({
    queryKey: ["/api/achievements/unlocked"],
  });

  if (authLoading || progressLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container max-w-6xl px-4 py-8">
          <div className="space-y-8">
            <Skeleton className="h-32 w-full" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Skeleton className="h-40" />
              <Skeleton className="h-40" />
              <Skeleton className="h-40" />
            </div>
          </div>
        </main>
      </div>
    );
  }

  const stats = [
    {
      icon: BookOpen,
      label: "Verses Practiced",
      value: progress?.totalVersesPracticed || 0,
      color: "text-primary",
    },
    {
      icon: Flame,
      label: "Current Streak",
      value: `${progress?.currentStreak || 0} days`,
      color: "text-chart-2",
    },
    {
      icon: Target,
      label: "Total Points",
      value: progress?.totalPoints || 0,
      color: "text-chart-5",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container max-w-6xl px-4 py-8">
        <div className="space-y-8">
          {/* Welcome Section */}
          <div className="text-center space-y-2">
            <h1 className="text-4xl md:text-5xl font-serif font-bold">
              Welcome Back!
            </h1>
            <p className="text-lg text-muted-foreground">
              Continue your journey of memorizing Scripture
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {stats.map((stat) => (
              <Card key={stat.label}>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    {stat.label}
                  </CardTitle>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <BookOpen className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>Practice Verses</CardTitle>
                    <CardDescription>
                      Continue memorizing with typing or speech
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Link href="/memorize">
                  <a>
                    <Button className="w-full" data-testid="button-practice">
                      Start Practicing
                    </Button>
                  </a>
                </Link>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Calendar className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>Daily Devotion</CardTitle>
                    <CardDescription>
                      Read today's devotional message
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Link href="/devotions">
                  <a>
                    <Button variant="outline" className="w-full" data-testid="button-devotion">
                      Read Devotion
                    </Button>
                  </a>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Recent Achievements */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                <CardTitle>Recent Achievements</CardTitle>
              </div>
              <CardDescription>
                Your latest unlocked badges
              </CardDescription>
            </CardHeader>
            <CardContent>
              {achievementsLoading ? (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[1, 2, 3, 4].map((i) => (
                    <Skeleton key={i} className="h-24" />
                  ))}
                </div>
              ) : unlockedAchievements && unlockedAchievements.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {unlockedAchievements.slice(0, 4).map((ua) => (
                    <div
                      key={ua.id}
                      className="flex flex-col items-center gap-2 p-4 rounded-lg bg-card border hover-elevate"
                      data-testid={`achievement-${ua.achievementId}`}
                    >
                      <div className="text-3xl">{getAchievementIcon(ua.achievement.iconType)}</div>
                      <div className="text-center">
                        <div className="font-semibold text-sm">{ua.achievement.name}</div>
                        <div className="text-xs text-muted-foreground">{ua.achievement.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Award className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Start practicing to unlock achievements!</p>
                </div>
              )}
              <Link href="/profile">
                <a>
                  <Button variant="link" className="mt-4 w-full" data-testid="button-view-all">
                    View All Achievements
                  </Button>
                </a>
              </Link>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function getAchievementIcon(iconType: string) {
  switch (iconType) {
    case "scroll":
      return "📜";
    case "flame":
      return "🔥";
    case "trophy":
      return "🏆";
    case "star":
      return "⭐";
    default:
      return "🎖️";
  }
}
