import { useEffect, useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Mic, MicOff, Type, RefreshCw, Check, BookOpen, Flame } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import type { Verse, UserProgress } from "@shared/schema";

export default function Memorize() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [practiceMode, setPracticeMode] = useState<"typing" | "speech">("typing");
  const [selectedVerseId, setSelectedVerseId] = useState<string>("");
  const [userInput, setUserInput] = useState("");
  const [spokenText, setSpokenText] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [comparison, setComparison] = useState<{ word: string; correct: boolean }[]>([]);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: verses, isLoading: versesLoading } = useQuery<Verse[]>({
    queryKey: ["/api/verses"],
  });

  const { data: progress } = useQuery<UserProgress>({
    queryKey: ["/api/progress"],
  });

  const selectedVerse = verses?.find(v => v.id === selectedVerseId);

  const practiceMutation = useMutation({
    mutationFn: async (data: { verseId: string; accuracy: number; practiceType: string }) => {
      return await apiRequest("POST", "/api/practice", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
      toast({
        title: "Great job!",
        description: "Your practice session has been recorded.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to record practice session.",
        variant: "destructive",
      });
    },
  });

  // Initialize speech recognition
  useEffect(() => {
    if (typeof window !== "undefined" && "webkitSpeechRecognition" in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setSpokenText(transcript);
        setIsListening(false);
        compareTexts(selectedVerse?.text || "", transcript);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
        toast({
          title: "Speech recognition error",
          description: "Please try again or use typing mode.",
          variant: "destructive",
        });
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const startListening = () => {
    if (recognitionRef.current && selectedVerse) {
      setSpokenText("");
      setComparison([]);
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const compareTexts = (original: string, input: string) => {
    const originalWords = original.toLowerCase().split(/\s+/);
    const inputWords = input.toLowerCase().split(/\s+/);
    
    const results: { word: string; correct: boolean }[] = [];
    const maxLength = Math.max(originalWords.length, inputWords.length);
    
    for (let i = 0; i < maxLength; i++) {
      if (i < inputWords.length) {
        results.push({
          word: inputWords[i],
          correct: originalWords[i] === inputWords[i],
        });
      }
    }
    
    setComparison(results);
    
    const correctCount = results.filter(r => r.correct).length;
    const accuracy = originalWords.length > 0 ? (correctCount / originalWords.length) * 100 : 0;
    
    if (selectedVerseId) {
      practiceMutation.mutate({
        verseId: selectedVerseId,
        accuracy: Math.round(accuracy),
        practiceType: practiceMode,
      });
    }
  };

  const handleTypingCheck = () => {
    if (selectedVerse && userInput.trim()) {
      compareTexts(selectedVerse.text, userInput);
    }
  };

  const handleReset = () => {
    setUserInput("");
    setSpokenText("");
    setComparison([]);
  };

  if (authLoading || versesLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container max-w-4xl px-4 py-8">
          <Skeleton className="h-96 w-full" />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container max-w-4xl px-4 py-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-serif font-bold">Memorize Verses</h1>
            <p className="text-lg text-muted-foreground">
              Practice by typing or speaking verses aloud
            </p>
          </div>

          {/* Stats Bar */}
          <div className="flex items-center justify-center gap-6">
            <Badge variant="outline" className="gap-2 px-4 py-2">
              <Flame className="h-4 w-4 text-chart-2" />
              <span>{progress?.currentStreak || 0} day streak</span>
            </Badge>
            <Badge variant="outline" className="gap-2 px-4 py-2">
              <BookOpen className="h-4 w-4 text-primary" />
              <span>{progress?.totalVersesPracticed || 0} verses</span>
            </Badge>
          </div>

          {/* Verse Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select a Verse</CardTitle>
              <CardDescription>
                Choose a verse to practice from the library
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={selectedVerseId} onValueChange={setSelectedVerseId}>
                <SelectTrigger data-testid="select-verse">
                  <SelectValue placeholder="Choose a verse..." />
                </SelectTrigger>
                <SelectContent>
                  {verses?.map((verse) => (
                    <SelectItem key={verse.id} value={verse.id}>
                      {verse.reference}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {selectedVerse && (
            <>
              {/* Verse Display */}
              <Card>
                <CardHeader>
                  <CardTitle className="font-serif text-2xl">{selectedVerse.reference}</CardTitle>
                  {selectedVerse.category && (
                    <Badge variant="secondary">{selectedVerse.category}</Badge>
                  )}
                </CardHeader>
                <CardContent>
                  <p className="font-verse text-xl leading-loose text-center">
                    "{selectedVerse.text}"
                  </p>
                </CardContent>
              </Card>

              {/* Practice Interface */}
              <Card>
                <CardHeader>
                  <CardTitle>Practice Mode</CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs value={practiceMode} onValueChange={(v) => setPracticeMode(v as "typing" | "speech")}>
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="typing" data-testid="tab-typing">
                        <Type className="h-4 w-4 mr-2" />
                        Typing
                      </TabsTrigger>
                      <TabsTrigger value="speech" data-testid="tab-speech">
                        <Mic className="h-4 w-4 mr-2" />
                        Speech
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="typing" className="space-y-4 mt-4">
                      <Textarea
                        placeholder="Type the verse here..."
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        className="min-h-32 font-verse text-lg"
                        data-testid="input-typing"
                      />
                      <div className="flex gap-2">
                        <Button onClick={handleTypingCheck} disabled={!userInput.trim()} data-testid="button-check">
                          <Check className="h-4 w-4 mr-2" />
                          Check Answer
                        </Button>
                        <Button variant="outline" onClick={handleReset} data-testid="button-reset">
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Reset
                        </Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="speech" className="space-y-4 mt-4">
                      <div className="flex flex-col items-center gap-4 py-8">
                        <Button
                          size="lg"
                          variant={isListening ? "destructive" : "default"}
                          className="h-24 w-24 rounded-full"
                          onClick={isListening ? stopListening : startListening}
                          data-testid="button-microphone"
                        >
                          {isListening ? (
                            <MicOff className="h-8 w-8" />
                          ) : (
                            <Mic className="h-8 w-8" />
                          )}
                        </Button>
                        <p className="text-sm text-muted-foreground">
                          {isListening ? "Listening... Click to stop" : "Click to start speaking"}
                        </p>
                        {spokenText && (
                          <div className="w-full p-4 bg-muted rounded-lg">
                            <p className="text-sm text-muted-foreground mb-1">You said:</p>
                            <p className="font-verse text-lg">{spokenText}</p>
                          </div>
                        )}
                      </div>
                      <Button variant="outline" onClick={handleReset} className="w-full" data-testid="button-reset-speech">
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Try Again
                      </Button>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>

              {/* Feedback Display */}
              {comparison.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Feedback</CardTitle>
                    <CardDescription>
                      Green = correct, Red = incorrect
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2 font-verse text-lg">
                      {comparison.map((item, idx) => (
                        <span
                          key={idx}
                          className={`px-2 py-1 rounded transition-colors ${
                            item.correct
                              ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
                              : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
                          }`}
                        >
                          {item.word}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
