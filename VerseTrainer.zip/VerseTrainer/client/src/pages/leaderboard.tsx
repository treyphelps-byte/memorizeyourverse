import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Trophy, Medal, Crown } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { User, UserProgress } from "@shared/schema";

type LeaderboardEntry = {
  user: User;
  progress: UserProgress;
  rank: number;
};

export default function Leaderboard() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: leaderboard, isLoading: leaderboardLoading } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard"],
  });

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-chart-2 fill-current" />;
      case 2:
        return <Medal className="h-6 w-6 text-muted-foreground fill-current" />;
      case 3:
        return <Medal className="h-6 w-6 text-chart-5 fill-current" />;
      default:
        return null;
    }
  };

  if (authLoading || leaderboardLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container max-w-4xl px-4 py-8">
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-20" />
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container max-w-4xl px-4 py-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <Trophy className="h-10 w-10 text-primary" />
              <h1 className="text-4xl font-serif font-bold">Leaderboard</h1>
            </div>
            <p className="text-lg text-muted-foreground">
              Top memorizers in the VerseTrainer community
            </p>
          </div>

          {/* Top 3 Podium */}
          {leaderboard && leaderboard.length >= 3 && (
            <div className="grid grid-cols-3 gap-4 mb-8">
              {/* 2nd Place */}
              <Card className="mt-8">
                <CardContent className="pt-6 text-center">
                  <div className="flex justify-center mb-2">
                    {getRankIcon(2)}
                  </div>
                  <Avatar className="h-16 w-16 mx-auto mb-2">
                    <AvatarImage src={leaderboard[1].user.profileImageUrl || undefined} style={{ objectFit: 'cover' }} />
                    <AvatarFallback>{leaderboard[1].user.firstName?.[0] || "U"}</AvatarFallback>
                  </Avatar>
                  <p className="font-semibold line-clamp-1">
                    {leaderboard[1].user.firstName || leaderboard[1].user.email}
                  </p>
                  <p className="text-2xl font-bold text-primary">
                    {leaderboard[1].progress.totalPoints}
                  </p>
                  <p className="text-xs text-muted-foreground">points</p>
                </CardContent>
              </Card>

              {/* 1st Place */}
              <Card className="border-primary">
                <CardContent className="pt-6 text-center">
                  <div className="flex justify-center mb-2">
                    {getRankIcon(1)}
                  </div>
                  <Avatar className="h-20 w-20 mx-auto mb-2 ring-2 ring-primary">
                    <AvatarImage src={leaderboard[0].user.profileImageUrl || undefined} style={{ objectFit: 'cover' }} />
                    <AvatarFallback>{leaderboard[0].user.firstName?.[0] || "U"}</AvatarFallback>
                  </Avatar>
                  <p className="font-semibold line-clamp-1">
                    {leaderboard[0].user.firstName || leaderboard[0].user.email}
                  </p>
                  <p className="text-3xl font-bold text-primary">
                    {leaderboard[0].progress.totalPoints}
                  </p>
                  <p className="text-xs text-muted-foreground">points</p>
                </CardContent>
              </Card>

              {/* 3rd Place */}
              <Card className="mt-8">
                <CardContent className="pt-6 text-center">
                  <div className="flex justify-center mb-2">
                    {getRankIcon(3)}
                  </div>
                  <Avatar className="h-16 w-16 mx-auto mb-2">
                    <AvatarImage src={leaderboard[2].user.profileImageUrl || undefined} style={{ objectFit: 'cover' }} />
                    <AvatarFallback>{leaderboard[2].user.firstName?.[0] || "U"}</AvatarFallback>
                  </Avatar>
                  <p className="font-semibold line-clamp-1">
                    {leaderboard[2].user.firstName || leaderboard[2].user.email}
                  </p>
                  <p className="text-2xl font-bold text-primary">
                    {leaderboard[2].progress.totalPoints}
                  </p>
                  <p className="text-xs text-muted-foreground">points</p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Full Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle>All Rankings</CardTitle>
              <CardDescription>Complete leaderboard standings</CardDescription>
            </CardHeader>
            <CardContent>
              {leaderboard && leaderboard.length > 0 ? (
                <div className="space-y-2">
                  {leaderboard.map((entry) => (
                    <div
                      key={entry.user.id}
                      className={`flex items-center gap-4 p-4 rounded-lg transition-colors hover-elevate ${
                        user?.id === entry.user.id ? "bg-accent" : ""
                      }`}
                      data-testid={`leaderboard-${entry.rank}`}
                    >
                      <div className="flex items-center justify-center w-12 h-12 rounded-full bg-muted font-bold">
                        {entry.rank <= 3 ? (
                          getRankIcon(entry.rank)
                        ) : (
                          <span className="text-lg">#{entry.rank}</span>
                        )}
                      </div>
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={entry.user.profileImageUrl || undefined} style={{ objectFit: 'cover' }} />
                        <AvatarFallback>{entry.user.firstName?.[0] || "U"}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-semibold">
                          {entry.user.firstName || entry.user.email}
                          {user?.id === entry.user.id && (
                            <span className="text-sm text-muted-foreground ml-2">(You)</span>
                          )}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {entry.progress.totalVersesPracticed} verses • {entry.progress.currentStreak} day streak
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-primary">
                          {entry.progress.totalPoints}
                        </p>
                        <p className="text-xs text-muted-foreground">points</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Trophy className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>No rankings yet. Start practicing to appear on the leaderboard!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
