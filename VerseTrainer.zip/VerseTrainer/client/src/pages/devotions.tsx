import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Heart, Calendar, BookOpen, Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import type { Devotion, ReadDevotion, FavoriteDevotion } from "@shared/schema";

type DevotionWithStatus = Devotion & {
  isRead: boolean;
  isFavorite: boolean;
};

export default function Devotions() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [selectedDevotion, setSelectedDevotion] = useState<DevotionWithStatus | null>(null);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: devotions, isLoading: devotionsLoading } = useQuery<DevotionWithStatus[]>({
    queryKey: ["/api/devotions"],
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (devotionId: string) => {
      return await apiRequest("POST", "/api/devotions/read", { devotionId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devotions"] });
      toast({
        title: "Marked as read",
        description: "Devotion has been marked as read.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to mark devotion as read.",
        variant: "destructive",
      });
    },
  });

  const toggleFavoriteMutation = useMutation({
    mutationFn: async ({ devotionId, isFavorite }: { devotionId: string; isFavorite: boolean }) => {
      if (isFavorite) {
        return await apiRequest("DELETE", `/api/devotions/${devotionId}/favorite`, {});
      } else {
        return await apiRequest("POST", "/api/devotions/favorite", { devotionId });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devotions"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update favorite.",
        variant: "destructive",
      });
    },
  });

  if (authLoading || devotionsLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container max-w-6xl px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-48" />
            ))}
          </div>
        </main>
      </div>
    );
  }

  if (selectedDevotion) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container max-w-3xl px-4 py-8">
          <div className="space-y-6">
            <Button variant="ghost" onClick={() => setSelectedDevotion(null)} data-testid="button-back">
              ← Back to Devotions
            </Button>

            <Card>
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-2">
                    <CardTitle className="font-serif text-3xl">{selectedDevotion.title}</CardTitle>
                    <CardDescription className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      {format(new Date(selectedDevotion.date), "MMMM d, yyyy")}
                    </CardDescription>
                    <Badge variant="outline" className="font-verse">
                      {selectedDevotion.scriptureReference}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() =>
                      toggleFavoriteMutation.mutate({
                        devotionId: selectedDevotion.id,
                        isFavorite: selectedDevotion.isFavorite,
                      })
                    }
                    data-testid="button-favorite"
                  >
                    <Heart
                      className={`h-5 w-5 ${selectedDevotion.isFavorite ? "fill-destructive text-destructive" : ""}`}
                    />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="prose prose-lg dark:prose-invert max-w-none">
                  <p className="font-verse leading-relaxed whitespace-pre-wrap">
                    {selectedDevotion.reflectionText}
                  </p>
                </div>

                {!selectedDevotion.isRead && (
                  <Button
                    onClick={() => markAsReadMutation.mutate(selectedDevotion.id)}
                    className="w-full"
                    disabled={markAsReadMutation.isPending}
                    data-testid="button-mark-read"
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Mark as Read
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container max-w-6xl px-4 py-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="text-center space-y-2">
            <h1 className="text-4xl font-serif font-bold">Daily Devotions</h1>
            <p className="text-lg text-muted-foreground">
              Grow in faith with daily reflections and Scripture
            </p>
          </div>

          {/* Devotions Grid */}
          {devotions && devotions.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {devotions.map((devotion) => (
                <Card
                  key={devotion.id}
                  className="hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer"
                  onClick={() => setSelectedDevotion(devotion)}
                  data-testid={`devotion-${devotion.id}`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs">
                            {format(new Date(devotion.date), "MMM d")}
                          </Badge>
                          {devotion.isRead && (
                            <Badge variant="outline" className="text-xs gap-1">
                              <Check className="h-3 w-3" />
                              Read
                            </Badge>
                          )}
                        </div>
                        <CardTitle className="font-serif text-xl line-clamp-2">
                          {devotion.title}
                        </CardTitle>
                        <CardDescription className="font-verse italic">
                          {devotion.scriptureReference}
                        </CardDescription>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavoriteMutation.mutate({
                            devotionId: devotion.id,
                            isFavorite: devotion.isFavorite,
                          });
                        }}
                        data-testid={`button-favorite-${devotion.id}`}
                      >
                        <Heart
                          className={`h-4 w-4 ${devotion.isFavorite ? "fill-destructive text-destructive" : ""}`}
                        />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed">
                      {devotion.reflectionText}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <BookOpen className="h-16 w-16 text-muted-foreground/50 mb-4" />
                <p className="text-lg text-muted-foreground mb-2">No devotions available yet</p>
                <p className="text-sm text-muted-foreground">Check back soon for daily reflections</p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
