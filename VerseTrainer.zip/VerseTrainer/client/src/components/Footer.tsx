import { BookOpen, Mail, Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t bg-card mt-auto">
      <div className="container px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="h-5 w-5 text-primary" />
              <span className="font-serif text-lg font-bold">VerseTrainer</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Helping believers memorize Scripture and grow in their faith through daily devotions and interactive practice.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="/memorize" className="text-muted-foreground hover:text-foreground transition-colors">Memorize Verses</a></li>
              <li><a href="/devotions" className="text-muted-foreground hover:text-foreground transition-colors">Daily Devotions</a></li>
              <li><a href="/leaderboard" className="text-muted-foreground hover:text-foreground transition-colors">Leaderboard</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Contact</h3>
            <div className="space-y-2 text-sm">
              <a href="mailto:support@versetrainer.com" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <Mail className="h-4 w-4" />
                support@versetrainer.com
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
          <p className="flex items-center justify-center gap-1">
            Made with <Heart className="h-4 w-4 text-destructive fill-current" /> for the faith community
          </p>
        </div>
      </div>
    </footer>
  );
}
