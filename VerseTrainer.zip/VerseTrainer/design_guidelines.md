# VerseTrainer Design Guidelines

## Design Approach

**Reference-Based Approach**: Drawing inspiration from learning/productivity apps (Duolingo, Notion, Headspace) combined with spiritual/wellness aesthetics. This application blends utility (memorization, tracking) with emotional engagement (devotion, spiritual growth), requiring both clarity and warmth in design.

**Core Principles**:
- Clarity and Focus: Learning interface should minimize distractions
- Encouragement: Visual feedback should be positive and motivating
- Accessibility: Spiritual content should be readable and welcoming
- Progress Visibility: Achievement and growth should be celebrated

## Typography System

**Font Families**:
- Primary (Headings): 'Merriweather' - serif font conveying timeless wisdom
- Secondary (Body): 'Inter' - clean sans-serif for optimal readability
- Accent (Verses): 'Crimson Text' - elegant serif for scripture display

**Type Scale**:
- Hero/Page Titles: text-5xl to text-6xl, font-bold
- Section Headings: text-3xl to text-4xl, font-semibold
- Card Titles: text-xl to text-2xl, font-semibold
- Body Text: text-base to text-lg, font-normal, leading-relaxed
- Verse Text: text-xl to text-2xl, leading-loose for comfortable reading
- UI Labels: text-sm, font-medium
- Captions: text-xs to text-sm

## Layout System

**Spacing Framework**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, and 24 consistently
- Component padding: p-4 to p-6 (mobile), p-6 to p-8 (desktop)
- Section spacing: py-12 to py-16 (mobile), py-16 to py-24 (desktop)
- Card gaps: gap-4 to gap-6
- Element spacing: space-y-4 to space-y-6

**Container Strategy**:
- Max-width: max-w-7xl for main content areas
- Verse display: max-w-3xl for optimal reading
- Form containers: max-w-md centered
- Dashboard grids: max-w-6xl

**Grid Patterns**:
- Stats Dashboard: 3-column on desktop (grid-cols-1 md:grid-cols-3)
- Achievement Badges: 4-column grid (grid-cols-2 md:grid-cols-4)
- Devotion Cards: 2-column on tablet+ (grid-cols-1 md:grid-cols-2)
- Leaderboard: Single column list with ranking indicators

## Component Library

### Navigation Header
- Fixed position with subtle shadow
- Logo/brand on left (icon + "VerseTrainer" text)
- Main nav links centered or right-aligned
- Profile avatar/menu on far right
- Dark mode toggle integrated into header
- Height: h-16, responsive collapse to hamburger on mobile

### Hero Section (Home Page)
**Image**: Large inspirational image (sunrise, open Bible, peaceful nature scene) with text overlay
- Hero height: min-h-[500px] to min-h-[600px]
- Image treatment: Subtle gradient overlay for text legibility
- CTA buttons with blurred background: backdrop-blur-sm
- Centered content with max-w-4xl
- Supporting text highlighting key features (e.g., "Join 10,000+ users memorizing Scripture daily")

### Verse Memorization Interface
**Card-based layout**:
- Large centered card (max-w-4xl) on clean background
- Verse display area: Large text, generous padding (p-8 to p-12)
- Input area: Full-width textarea or speech button
- Real-time feedback display: Word-by-word highlighting inline
- Progress indicator: Slim progress bar at top of card
- Action buttons: Large, prominent (Speak, Type, Next Verse, Reset)
- Sidebar stats: Compact widgets showing streak, accuracy, verses completed

**Speech Recognition Feedback**:
- Words appear with colored background highlights
- Smooth transitions for highlighting (transition-colors duration-300)
- Clear visual separation between words (gap-2)
- Microphone button: Large, circular, pulsing animation when active

### Daily Devotion Cards
- Card grid layout with consistent sizing
- Each card includes:
  - Date badge (top-right corner)
  - Devotion title (text-xl, font-semibold)
  - Scripture reference (text-sm, italic)
  - Preview text (2-3 lines, text-base, line-clamp-3)
  - Action buttons: "Read" and heart icon for favorites
- Hover state: Subtle lift effect (hover:shadow-lg, hover:-translate-y-1)
- Card padding: p-6
- Rounded corners: rounded-lg to rounded-xl

### Full Devotion View
- Single column layout (max-w-3xl)
- Large title with scripture reference
- Full reflection text with comfortable line-height (leading-relaxed)
- "Mark as Read" button at bottom
- Previous/Next navigation
- Return to list link

### Progress Dashboard
**Multi-widget layout**:
- Stat cards in 3-column grid showing:
  - Total verses practiced
  - Current streak (with fire icon)
  - Average accuracy percentage
- Recent activity timeline
- Achievement showcase: Badge grid with locked/unlocked states
- Progress charts: Simple bar or line charts for trends

### Leaderboard
- Ranked list with position numbers
- User rows showing: Rank, Avatar, Name, Points, Verses Count
- Current user row highlighted
- Top 3 special styling (medal icons)
- Pagination or infinite scroll for long lists

### Forms (Sign Up/Login)
- Centered cards (max-w-md)
- Generous spacing between fields (space-y-6)
- Clear labels above inputs
- Input fields: rounded-lg, p-3, border focus states
- Primary action button: Full width, prominent
- Social login options with icon buttons
- Toggle between sign up/login

### Badges and Gamification
- Circular or shield-shaped badges
- Grid display with labels
- Locked badges: Grayscale with lock icon overlay
- Unlocked badges: Full visual treatment with shine/glow effect
- Tooltip showing badge requirements on hover

### Footer
- Multi-column layout on desktop, stacked on mobile
- Sections: About, Quick Links, Contact, Social
- Newsletter signup: Email input + subscribe button
- Copyright and links
- Padding: py-12, background distinct from main content

## Images

**Hero Image**: 
- Peaceful, uplifting scene (sunrise over landscape, open Bible with soft lighting, or person reading in serene setting)
- Position: Hero section background
- Treatment: Subtle dark gradient overlay (from transparent to semi-dark) for text contrast

**Devotion Thumbnails** (Optional):
- Small imagery for each devotion (abstract spiritual themes, nature, light)
- Size: aspect-ratio 16/9, small within cards
- Position: Top of devotion cards

**Achievement Badge Icons**:
- Custom designed icons for different milestones
- Examples: "First Verse" (scroll), "7 Day Streak" (flame), "100 Verses" (trophy)
- Style: Simple, iconic, recognizable at small sizes

## Interaction Patterns

**Transitions**: Use sparingly and purposefully
- Card hovers: Subtle lift (transition-transform duration-200)
- Button states: Quick color transitions (transition-colors duration-150)
- Speech recognition: Pulsing microphone animation
- Page transitions: Smooth fade-ins for new content

**Feedback Mechanisms**:
- Toast notifications for achievements (top-right corner)
- Inline validation for forms (below inputs)
- Loading states: Spinner or skeleton screens
- Success animations: Checkmark or confetti for milestones

**Responsive Behavior**:
- Mobile-first approach
- Navigation collapses to hamburger menu below md breakpoint
- Multi-column layouts stack to single column on mobile
- Touch-friendly button sizing (min-h-12) on mobile
- Adequate spacing for thumb navigation

## Dark Mode Implementation
- Toggle switch in header (moon/sun icons)
- Smooth transition between modes (transition-colors duration-300)
- Adjust all backgrounds, text, borders, and shadows
- Maintain readability and contrast in both modes
- Persist preference in localStorage

This design creates a harmonious balance between a productivity tool and a spiritual companion, with clear information hierarchy, encouraging visual feedback, and an uplifting aesthetic that supports the user's faith journey.